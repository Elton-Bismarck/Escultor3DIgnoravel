/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.12)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../untitled/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.12. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[64];
    char stringdata0[293];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 4), // "sair"
QT_MOC_LITERAL(2, 16, 0), // ""
QT_MOC_LITERAL(3, 17, 4), // "RGBR"
QT_MOC_LITERAL(4, 22, 2), // "_r"
QT_MOC_LITERAL(5, 25, 4), // "RGBG"
QT_MOC_LITERAL(6, 30, 2), // "_g"
QT_MOC_LITERAL(7, 33, 4), // "RGBB"
QT_MOC_LITERAL(8, 38, 2), // "_b"
QT_MOC_LITERAL(9, 41, 3), // "cor"
QT_MOC_LITERAL(10, 45, 2), // "m1"
QT_MOC_LITERAL(11, 48, 2), // "m2"
QT_MOC_LITERAL(12, 51, 2), // "m3"
QT_MOC_LITERAL(13, 54, 2), // "m4"
QT_MOC_LITERAL(14, 57, 2), // "m5"
QT_MOC_LITERAL(15, 60, 2), // "m6"
QT_MOC_LITERAL(16, 63, 2), // "m7"
QT_MOC_LITERAL(17, 66, 2), // "m8"
QT_MOC_LITERAL(18, 69, 2), // "m9"
QT_MOC_LITERAL(19, 72, 3), // "m10"
QT_MOC_LITERAL(20, 76, 3), // "m11"
QT_MOC_LITERAL(21, 80, 3), // "m12"
QT_MOC_LITERAL(22, 84, 3), // "m13"
QT_MOC_LITERAL(23, 88, 3), // "m14"
QT_MOC_LITERAL(24, 92, 3), // "m15"
QT_MOC_LITERAL(25, 96, 3), // "m16"
QT_MOC_LITERAL(26, 100, 3), // "m17"
QT_MOC_LITERAL(27, 104, 3), // "m18"
QT_MOC_LITERAL(28, 108, 3), // "m19"
QT_MOC_LITERAL(29, 112, 3), // "m20"
QT_MOC_LITERAL(30, 116, 3), // "m21"
QT_MOC_LITERAL(31, 120, 3), // "m22"
QT_MOC_LITERAL(32, 124, 3), // "m23"
QT_MOC_LITERAL(33, 128, 3), // "m24"
QT_MOC_LITERAL(34, 132, 3), // "m25"
QT_MOC_LITERAL(35, 136, 3), // "m26"
QT_MOC_LITERAL(36, 140, 3), // "m27"
QT_MOC_LITERAL(37, 144, 3), // "m28"
QT_MOC_LITERAL(38, 148, 3), // "m29"
QT_MOC_LITERAL(39, 152, 3), // "m30"
QT_MOC_LITERAL(40, 156, 3), // "m31"
QT_MOC_LITERAL(41, 160, 3), // "m32"
QT_MOC_LITERAL(42, 164, 3), // "m33"
QT_MOC_LITERAL(43, 168, 3), // "m34"
QT_MOC_LITERAL(44, 172, 3), // "m35"
QT_MOC_LITERAL(45, 176, 3), // "m36"
QT_MOC_LITERAL(46, 180, 3), // "m37"
QT_MOC_LITERAL(47, 184, 3), // "m38"
QT_MOC_LITERAL(48, 188, 3), // "m39"
QT_MOC_LITERAL(49, 192, 3), // "m40"
QT_MOC_LITERAL(50, 196, 3), // "m41"
QT_MOC_LITERAL(51, 200, 3), // "m42"
QT_MOC_LITERAL(52, 204, 8), // "putvoxel"
QT_MOC_LITERAL(53, 213, 8), // "cutvoxel"
QT_MOC_LITERAL(54, 222, 6), // "putbox"
QT_MOC_LITERAL(55, 229, 6), // "cutbox"
QT_MOC_LITERAL(56, 236, 9), // "putsphere"
QT_MOC_LITERAL(57, 246, 9), // "cutsphere"
QT_MOC_LITERAL(58, 256, 10), // "putellipse"
QT_MOC_LITERAL(59, 267, 10), // "cutellipse"
QT_MOC_LITERAL(60, 278, 8), // "desenhar"
QT_MOC_LITERAL(61, 287, 1), // "x"
QT_MOC_LITERAL(62, 289, 1), // "y"
QT_MOC_LITERAL(63, 291, 1) // "z"

    },
    "MainWindow\0sair\0\0RGBR\0_r\0RGBG\0_g\0RGBB\0"
    "_b\0cor\0m1\0m2\0m3\0m4\0m5\0m6\0m7\0m8\0m9\0m10\0"
    "m11\0m12\0m13\0m14\0m15\0m16\0m17\0m18\0m19\0"
    "m20\0m21\0m22\0m23\0m24\0m25\0m26\0m27\0m28\0"
    "m29\0m30\0m31\0m32\0m33\0m34\0m35\0m36\0m37\0"
    "m38\0m39\0m40\0m41\0m42\0putvoxel\0cutvoxel\0"
    "putbox\0cutbox\0putsphere\0cutsphere\0"
    "putellipse\0cutellipse\0desenhar\0x\0y\0z"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      56,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  294,    2, 0x0a /* Public */,
       3,    1,  295,    2, 0x0a /* Public */,
       5,    1,  298,    2, 0x0a /* Public */,
       7,    1,  301,    2, 0x0a /* Public */,
       9,    0,  304,    2, 0x0a /* Public */,
      10,    0,  305,    2, 0x0a /* Public */,
      11,    0,  306,    2, 0x0a /* Public */,
      12,    0,  307,    2, 0x0a /* Public */,
      13,    0,  308,    2, 0x0a /* Public */,
      14,    0,  309,    2, 0x0a /* Public */,
      15,    0,  310,    2, 0x0a /* Public */,
      16,    0,  311,    2, 0x0a /* Public */,
      17,    0,  312,    2, 0x0a /* Public */,
      18,    0,  313,    2, 0x0a /* Public */,
      19,    0,  314,    2, 0x0a /* Public */,
      20,    0,  315,    2, 0x0a /* Public */,
      21,    0,  316,    2, 0x0a /* Public */,
      22,    0,  317,    2, 0x0a /* Public */,
      23,    0,  318,    2, 0x0a /* Public */,
      24,    0,  319,    2, 0x0a /* Public */,
      25,    0,  320,    2, 0x0a /* Public */,
      26,    0,  321,    2, 0x0a /* Public */,
      27,    0,  322,    2, 0x0a /* Public */,
      28,    0,  323,    2, 0x0a /* Public */,
      29,    0,  324,    2, 0x0a /* Public */,
      30,    0,  325,    2, 0x0a /* Public */,
      31,    0,  326,    2, 0x0a /* Public */,
      32,    0,  327,    2, 0x0a /* Public */,
      33,    0,  328,    2, 0x0a /* Public */,
      34,    0,  329,    2, 0x0a /* Public */,
      35,    0,  330,    2, 0x0a /* Public */,
      36,    0,  331,    2, 0x0a /* Public */,
      37,    0,  332,    2, 0x0a /* Public */,
      38,    0,  333,    2, 0x0a /* Public */,
      39,    0,  334,    2, 0x0a /* Public */,
      40,    0,  335,    2, 0x0a /* Public */,
      41,    0,  336,    2, 0x0a /* Public */,
      42,    0,  337,    2, 0x0a /* Public */,
      43,    0,  338,    2, 0x0a /* Public */,
      44,    0,  339,    2, 0x0a /* Public */,
      45,    0,  340,    2, 0x0a /* Public */,
      46,    0,  341,    2, 0x0a /* Public */,
      47,    0,  342,    2, 0x0a /* Public */,
      48,    0,  343,    2, 0x0a /* Public */,
      49,    0,  344,    2, 0x0a /* Public */,
      50,    0,  345,    2, 0x0a /* Public */,
      51,    0,  346,    2, 0x0a /* Public */,
      52,    0,  347,    2, 0x08 /* Private */,
      53,    0,  348,    2, 0x08 /* Private */,
      54,    0,  349,    2, 0x08 /* Private */,
      55,    0,  350,    2, 0x08 /* Private */,
      56,    0,  351,    2, 0x08 /* Private */,
      57,    0,  352,    2, 0x08 /* Private */,
      58,    0,  353,    2, 0x08 /* Private */,
      59,    0,  354,    2, 0x08 /* Private */,
      60,    3,  355,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void, QMetaType::Int,    8,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int,   61,   62,   63,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sair(); break;
        case 1: _t->RGBR((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->RGBG((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->RGBB((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->cor(); break;
        case 5: _t->m1(); break;
        case 6: _t->m2(); break;
        case 7: _t->m3(); break;
        case 8: _t->m4(); break;
        case 9: _t->m5(); break;
        case 10: _t->m6(); break;
        case 11: _t->m7(); break;
        case 12: _t->m8(); break;
        case 13: _t->m9(); break;
        case 14: _t->m10(); break;
        case 15: _t->m11(); break;
        case 16: _t->m12(); break;
        case 17: _t->m13(); break;
        case 18: _t->m14(); break;
        case 19: _t->m15(); break;
        case 20: _t->m16(); break;
        case 21: _t->m17(); break;
        case 22: _t->m18(); break;
        case 23: _t->m19(); break;
        case 24: _t->m20(); break;
        case 25: _t->m21(); break;
        case 26: _t->m22(); break;
        case 27: _t->m23(); break;
        case 28: _t->m24(); break;
        case 29: _t->m25(); break;
        case 30: _t->m26(); break;
        case 31: _t->m27(); break;
        case 32: _t->m28(); break;
        case 33: _t->m29(); break;
        case 34: _t->m30(); break;
        case 35: _t->m31(); break;
        case 36: _t->m32(); break;
        case 37: _t->m33(); break;
        case 38: _t->m34(); break;
        case 39: _t->m35(); break;
        case 40: _t->m36(); break;
        case 41: _t->m37(); break;
        case 42: _t->m38(); break;
        case 43: _t->m39(); break;
        case 44: _t->m40(); break;
        case 45: _t->m41(); break;
        case 46: _t->m42(); break;
        case 47: _t->putvoxel(); break;
        case 48: _t->cutvoxel(); break;
        case 49: _t->putbox(); break;
        case 50: _t->cutbox(); break;
        case 51: _t->putsphere(); break;
        case 52: _t->cutsphere(); break;
        case 53: _t->putellipse(); break;
        case 54: _t->cutellipse(); break;
        case 55: _t->desenhar((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 56)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 56;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 56)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 56;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
