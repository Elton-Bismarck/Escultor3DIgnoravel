/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *ButtonQuit;
    QPushButton *ButtonCor;
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QPushButton *Bcubo;
    QPushButton *BNcubo;
    QPushButton *Besfera;
    QPushButton *BNesfera;
    QPushButton *Belipsoide;
    QPushButton *BNelipsoide;
    QPushButton *Bvoxel;
    QPushButton *BNvoxel;
    QWidget *layoutWidget1;
    QGridLayout *gridLayout_2;
    QSlider *SliderR;
    QLCDNumber *lcdNumber;
    QLabel *labelG;
    QSlider *SliderG;
    QLCDNumber *lcdNumber_2;
    QSlider *SliderB;
    QLCDNumber *lcdNumber_3;
    QLabel *labelR;
    QLabel *labelB;
    QWidget *layoutWidget2;
    QGridLayout *gridLayout_3;
    QSlider *SliderX;
    QLCDNumber *lcdNumber_4;
    QLabel *labelG_2;
    QSlider *SliderY;
    QLCDNumber *lcdNumber_5;
    QLabel *labelB_2;
    QSlider *SliderZ;
    QLCDNumber *lcdNumber_6;
    QLabel *labelB_3;
    QSlider *SliderR2;
    QLCDNumber *lcdNumber_7;
    QLabel *labelR_2;
    QWidget *layoutWidget3;
    QGridLayout *gridLayout_4;
    QLabel *labelR_3;
    QSlider *SliderPZ;
    QLCDNumber *lcdNumber_8;
    QWidget *layoutWidget4;
    QGridLayout *gridLayout_5;
    QPushButton *b1;
    QPushButton *b2;
    QPushButton *b11;
    QPushButton *b19;
    QPushButton *b30;
    QPushButton *b10;
    QPushButton *b14;
    QPushButton *b36;
    QPushButton *b24;
    QPushButton *b9;
    QPushButton *b5;
    QPushButton *b18;
    QPushButton *b20;
    QPushButton *b27;
    QPushButton *b39;
    QPushButton *b8;
    QPushButton *b28;
    QPushButton *b3;
    QPushButton *b26;
    QPushButton *b16;
    QPushButton *b22;
    QPushButton *b31;
    QPushButton *b40;
    QPushButton *b15;
    QPushButton *b7;
    QPushButton *b25;
    QPushButton *b32;
    QPushButton *b12;
    QPushButton *b34;
    QPushButton *b4;
    QPushButton *b33;
    QPushButton *b13;
    QPushButton *b21;
    QPushButton *b23;
    QPushButton *b42;
    QPushButton *b38;
    QPushButton *b17;
    QPushButton *b37;
    QPushButton *b35;
    QPushButton *b6;
    QPushButton *b29;
    QPushButton *b41;
    QLabel *label;
    QLabel *label_2;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(802, 520);
        QFont font;
        font.setFamily(QString::fromUtf8("Arial Black"));
        font.setPointSize(10);
        font.setBold(true);
        font.setWeight(75);
        MainWindow->setFont(font);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        ButtonQuit = new QPushButton(centralwidget);
        ButtonQuit->setObjectName(QString::fromUtf8("ButtonQuit"));
        ButtonQuit->setGeometry(QRect(360, 440, 91, 31));
        ButtonCor = new QPushButton(centralwidget);
        ButtonCor->setObjectName(QString::fromUtf8("ButtonCor"));
        ButtonCor->setGeometry(QRect(620, 300, 171, 23));
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(620, 0, 167, 124));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        Bcubo = new QPushButton(layoutWidget);
        Bcubo->setObjectName(QString::fromUtf8("Bcubo"));

        gridLayout->addWidget(Bcubo, 1, 0, 1, 1);

        BNcubo = new QPushButton(layoutWidget);
        BNcubo->setObjectName(QString::fromUtf8("BNcubo"));

        gridLayout->addWidget(BNcubo, 1, 1, 1, 2);

        Besfera = new QPushButton(layoutWidget);
        Besfera->setObjectName(QString::fromUtf8("Besfera"));

        gridLayout->addWidget(Besfera, 2, 0, 1, 1);

        BNesfera = new QPushButton(layoutWidget);
        BNesfera->setObjectName(QString::fromUtf8("BNesfera"));

        gridLayout->addWidget(BNesfera, 2, 1, 1, 2);

        Belipsoide = new QPushButton(layoutWidget);
        Belipsoide->setObjectName(QString::fromUtf8("Belipsoide"));

        gridLayout->addWidget(Belipsoide, 3, 0, 1, 1);

        BNelipsoide = new QPushButton(layoutWidget);
        BNelipsoide->setObjectName(QString::fromUtf8("BNelipsoide"));

        gridLayout->addWidget(BNelipsoide, 3, 1, 1, 2);

        Bvoxel = new QPushButton(layoutWidget);
        Bvoxel->setObjectName(QString::fromUtf8("Bvoxel"));

        gridLayout->addWidget(Bvoxel, 0, 0, 1, 1);

        BNvoxel = new QPushButton(layoutWidget);
        BNvoxel->setObjectName(QString::fromUtf8("BNvoxel"));

        gridLayout->addWidget(BNvoxel, 0, 1, 1, 2);

        layoutWidget1 = new QWidget(centralwidget);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(620, 130, 171, 158));
        gridLayout_2 = new QGridLayout(layoutWidget1);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        SliderR = new QSlider(layoutWidget1);
        SliderR->setObjectName(QString::fromUtf8("SliderR"));
        SliderR->setMinimum(1);
        SliderR->setMaximum(100);
        SliderR->setOrientation(Qt::Horizontal);

        gridLayout_2->addWidget(SliderR, 0, 1, 1, 1);

        lcdNumber = new QLCDNumber(layoutWidget1);
        lcdNumber->setObjectName(QString::fromUtf8("lcdNumber"));

        gridLayout_2->addWidget(lcdNumber, 1, 1, 1, 1);

        labelG = new QLabel(layoutWidget1);
        labelG->setObjectName(QString::fromUtf8("labelG"));

        gridLayout_2->addWidget(labelG, 2, 0, 2, 1);

        SliderG = new QSlider(layoutWidget1);
        SliderG->setObjectName(QString::fromUtf8("SliderG"));
        SliderG->setMinimum(1);
        SliderG->setMaximum(100);
        SliderG->setOrientation(Qt::Horizontal);

        gridLayout_2->addWidget(SliderG, 2, 1, 1, 1);

        lcdNumber_2 = new QLCDNumber(layoutWidget1);
        lcdNumber_2->setObjectName(QString::fromUtf8("lcdNumber_2"));

        gridLayout_2->addWidget(lcdNumber_2, 3, 1, 1, 1);

        SliderB = new QSlider(layoutWidget1);
        SliderB->setObjectName(QString::fromUtf8("SliderB"));
        SliderB->setMinimum(1);
        SliderB->setMaximum(100);
        SliderB->setOrientation(Qt::Horizontal);

        gridLayout_2->addWidget(SliderB, 4, 1, 1, 1);

        lcdNumber_3 = new QLCDNumber(layoutWidget1);
        lcdNumber_3->setObjectName(QString::fromUtf8("lcdNumber_3"));

        gridLayout_2->addWidget(lcdNumber_3, 5, 1, 1, 1);

        labelR = new QLabel(layoutWidget1);
        labelR->setObjectName(QString::fromUtf8("labelR"));

        gridLayout_2->addWidget(labelR, 0, 0, 2, 1);

        labelB = new QLabel(layoutWidget1);
        labelB->setObjectName(QString::fromUtf8("labelB"));

        gridLayout_2->addWidget(labelB, 4, 0, 2, 1);

        layoutWidget2 = new QWidget(centralwidget);
        layoutWidget2->setObjectName(QString::fromUtf8("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(10, 10, 161, 212));
        gridLayout_3 = new QGridLayout(layoutWidget2);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setContentsMargins(0, 0, 0, 0);
        SliderX = new QSlider(layoutWidget2);
        SliderX->setObjectName(QString::fromUtf8("SliderX"));
        SliderX->setMinimum(1);
        SliderX->setMaximum(7);
        SliderX->setOrientation(Qt::Horizontal);

        gridLayout_3->addWidget(SliderX, 0, 2, 1, 1);

        lcdNumber_4 = new QLCDNumber(layoutWidget2);
        lcdNumber_4->setObjectName(QString::fromUtf8("lcdNumber_4"));

        gridLayout_3->addWidget(lcdNumber_4, 1, 2, 1, 1);

        labelG_2 = new QLabel(layoutWidget2);
        labelG_2->setObjectName(QString::fromUtf8("labelG_2"));

        gridLayout_3->addWidget(labelG_2, 2, 0, 1, 2);

        SliderY = new QSlider(layoutWidget2);
        SliderY->setObjectName(QString::fromUtf8("SliderY"));
        SliderY->setMinimum(1);
        SliderY->setMaximum(7);
        SliderY->setOrientation(Qt::Horizontal);

        gridLayout_3->addWidget(SliderY, 2, 2, 1, 1);

        lcdNumber_5 = new QLCDNumber(layoutWidget2);
        lcdNumber_5->setObjectName(QString::fromUtf8("lcdNumber_5"));

        gridLayout_3->addWidget(lcdNumber_5, 3, 2, 1, 1);

        labelB_2 = new QLabel(layoutWidget2);
        labelB_2->setObjectName(QString::fromUtf8("labelB_2"));

        gridLayout_3->addWidget(labelB_2, 4, 0, 1, 2);

        SliderZ = new QSlider(layoutWidget2);
        SliderZ->setObjectName(QString::fromUtf8("SliderZ"));
        SliderZ->setMinimum(1);
        SliderZ->setMaximum(7);
        SliderZ->setOrientation(Qt::Horizontal);

        gridLayout_3->addWidget(SliderZ, 4, 2, 1, 1);

        lcdNumber_6 = new QLCDNumber(layoutWidget2);
        lcdNumber_6->setObjectName(QString::fromUtf8("lcdNumber_6"));

        gridLayout_3->addWidget(lcdNumber_6, 5, 2, 1, 1);

        labelB_3 = new QLabel(layoutWidget2);
        labelB_3->setObjectName(QString::fromUtf8("labelB_3"));

        gridLayout_3->addWidget(labelB_3, 6, 0, 1, 1);

        SliderR2 = new QSlider(layoutWidget2);
        SliderR2->setObjectName(QString::fromUtf8("SliderR2"));
        SliderR2->setMinimum(1);
        SliderR2->setMaximum(7);
        SliderR2->setOrientation(Qt::Horizontal);

        gridLayout_3->addWidget(SliderR2, 6, 1, 1, 2);

        lcdNumber_7 = new QLCDNumber(layoutWidget2);
        lcdNumber_7->setObjectName(QString::fromUtf8("lcdNumber_7"));

        gridLayout_3->addWidget(lcdNumber_7, 7, 1, 1, 2);

        labelR_2 = new QLabel(layoutWidget2);
        labelR_2->setObjectName(QString::fromUtf8("labelR_2"));

        gridLayout_3->addWidget(labelR_2, 0, 0, 1, 2);

        layoutWidget3 = new QWidget(centralwidget);
        layoutWidget3->setObjectName(QString::fromUtf8("layoutWidget3"));
        layoutWidget3->setGeometry(QRect(10, 230, 161, 50));
        gridLayout_4 = new QGridLayout(layoutWidget3);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        gridLayout_4->setContentsMargins(0, 0, 0, 0);
        labelR_3 = new QLabel(layoutWidget3);
        labelR_3->setObjectName(QString::fromUtf8("labelR_3"));

        gridLayout_4->addWidget(labelR_3, 0, 0, 1, 1);

        SliderPZ = new QSlider(layoutWidget3);
        SliderPZ->setObjectName(QString::fromUtf8("SliderPZ"));
        SliderPZ->setMinimum(1);
        SliderPZ->setMaximum(7);
        SliderPZ->setOrientation(Qt::Horizontal);

        gridLayout_4->addWidget(SliderPZ, 0, 1, 1, 1);

        lcdNumber_8 = new QLCDNumber(layoutWidget3);
        lcdNumber_8->setObjectName(QString::fromUtf8("lcdNumber_8"));

        gridLayout_4->addWidget(lcdNumber_8, 1, 1, 1, 1);

        layoutWidget4 = new QWidget(centralwidget);
        layoutWidget4->setObjectName(QString::fromUtf8("layoutWidget4"));
        layoutWidget4->setGeometry(QRect(180, 10, 431, 421));
        gridLayout_5 = new QGridLayout(layoutWidget4);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        gridLayout_5->setContentsMargins(0, 0, 0, 0);
        b1 = new QPushButton(layoutWidget4);
        b1->setObjectName(QString::fromUtf8("b1"));

        gridLayout_5->addWidget(b1, 0, 0, 1, 1);

        b2 = new QPushButton(layoutWidget4);
        b2->setObjectName(QString::fromUtf8("b2"));

        gridLayout_5->addWidget(b2, 0, 1, 1, 1);

        b11 = new QPushButton(layoutWidget4);
        b11->setObjectName(QString::fromUtf8("b11"));

        gridLayout_5->addWidget(b11, 1, 3, 1, 1);

        b19 = new QPushButton(layoutWidget4);
        b19->setObjectName(QString::fromUtf8("b19"));

        gridLayout_5->addWidget(b19, 2, 4, 1, 1);

        b30 = new QPushButton(layoutWidget4);
        b30->setObjectName(QString::fromUtf8("b30"));

        gridLayout_5->addWidget(b30, 4, 1, 1, 1);

        b10 = new QPushButton(layoutWidget4);
        b10->setObjectName(QString::fromUtf8("b10"));

        gridLayout_5->addWidget(b10, 1, 2, 1, 1);

        b14 = new QPushButton(layoutWidget4);
        b14->setObjectName(QString::fromUtf8("b14"));

        gridLayout_5->addWidget(b14, 1, 6, 1, 1);

        b36 = new QPushButton(layoutWidget4);
        b36->setObjectName(QString::fromUtf8("b36"));

        gridLayout_5->addWidget(b36, 5, 0, 1, 1);

        b24 = new QPushButton(layoutWidget4);
        b24->setObjectName(QString::fromUtf8("b24"));

        gridLayout_5->addWidget(b24, 3, 2, 1, 1);

        b9 = new QPushButton(layoutWidget4);
        b9->setObjectName(QString::fromUtf8("b9"));

        gridLayout_5->addWidget(b9, 1, 1, 1, 1);

        b5 = new QPushButton(layoutWidget4);
        b5->setObjectName(QString::fromUtf8("b5"));

        gridLayout_5->addWidget(b5, 0, 4, 1, 1);

        b18 = new QPushButton(layoutWidget4);
        b18->setObjectName(QString::fromUtf8("b18"));

        gridLayout_5->addWidget(b18, 2, 3, 1, 1);

        b20 = new QPushButton(layoutWidget4);
        b20->setObjectName(QString::fromUtf8("b20"));

        gridLayout_5->addWidget(b20, 2, 5, 1, 1);

        b27 = new QPushButton(layoutWidget4);
        b27->setObjectName(QString::fromUtf8("b27"));

        gridLayout_5->addWidget(b27, 3, 5, 1, 1);

        b39 = new QPushButton(layoutWidget4);
        b39->setObjectName(QString::fromUtf8("b39"));

        gridLayout_5->addWidget(b39, 5, 3, 1, 1);

        b8 = new QPushButton(layoutWidget4);
        b8->setObjectName(QString::fromUtf8("b8"));

        gridLayout_5->addWidget(b8, 1, 0, 1, 1);

        b28 = new QPushButton(layoutWidget4);
        b28->setObjectName(QString::fromUtf8("b28"));

        gridLayout_5->addWidget(b28, 3, 6, 1, 1);

        b3 = new QPushButton(layoutWidget4);
        b3->setObjectName(QString::fromUtf8("b3"));

        gridLayout_5->addWidget(b3, 0, 2, 1, 1);

        b26 = new QPushButton(layoutWidget4);
        b26->setObjectName(QString::fromUtf8("b26"));

        gridLayout_5->addWidget(b26, 3, 4, 1, 1);

        b16 = new QPushButton(layoutWidget4);
        b16->setObjectName(QString::fromUtf8("b16"));

        gridLayout_5->addWidget(b16, 2, 1, 1, 1);

        b22 = new QPushButton(layoutWidget4);
        b22->setObjectName(QString::fromUtf8("b22"));

        gridLayout_5->addWidget(b22, 3, 0, 1, 1);

        b31 = new QPushButton(layoutWidget4);
        b31->setObjectName(QString::fromUtf8("b31"));

        gridLayout_5->addWidget(b31, 4, 2, 1, 1);

        b40 = new QPushButton(layoutWidget4);
        b40->setObjectName(QString::fromUtf8("b40"));

        gridLayout_5->addWidget(b40, 5, 4, 1, 1);

        b15 = new QPushButton(layoutWidget4);
        b15->setObjectName(QString::fromUtf8("b15"));

        gridLayout_5->addWidget(b15, 2, 0, 1, 1);

        b7 = new QPushButton(layoutWidget4);
        b7->setObjectName(QString::fromUtf8("b7"));

        gridLayout_5->addWidget(b7, 0, 6, 1, 1);

        b25 = new QPushButton(layoutWidget4);
        b25->setObjectName(QString::fromUtf8("b25"));

        gridLayout_5->addWidget(b25, 3, 3, 1, 1);

        b32 = new QPushButton(layoutWidget4);
        b32->setObjectName(QString::fromUtf8("b32"));

        gridLayout_5->addWidget(b32, 4, 3, 1, 1);

        b12 = new QPushButton(layoutWidget4);
        b12->setObjectName(QString::fromUtf8("b12"));

        gridLayout_5->addWidget(b12, 1, 4, 1, 1);

        b34 = new QPushButton(layoutWidget4);
        b34->setObjectName(QString::fromUtf8("b34"));

        gridLayout_5->addWidget(b34, 4, 5, 1, 1);

        b4 = new QPushButton(layoutWidget4);
        b4->setObjectName(QString::fromUtf8("b4"));

        gridLayout_5->addWidget(b4, 0, 3, 1, 1);

        b33 = new QPushButton(layoutWidget4);
        b33->setObjectName(QString::fromUtf8("b33"));

        gridLayout_5->addWidget(b33, 4, 4, 1, 1);

        b13 = new QPushButton(layoutWidget4);
        b13->setObjectName(QString::fromUtf8("b13"));

        gridLayout_5->addWidget(b13, 1, 5, 1, 1);

        b21 = new QPushButton(layoutWidget4);
        b21->setObjectName(QString::fromUtf8("b21"));

        gridLayout_5->addWidget(b21, 2, 6, 1, 1);

        b23 = new QPushButton(layoutWidget4);
        b23->setObjectName(QString::fromUtf8("b23"));

        gridLayout_5->addWidget(b23, 3, 1, 1, 1);

        b42 = new QPushButton(layoutWidget4);
        b42->setObjectName(QString::fromUtf8("b42"));

        gridLayout_5->addWidget(b42, 5, 6, 1, 1);

        b38 = new QPushButton(layoutWidget4);
        b38->setObjectName(QString::fromUtf8("b38"));

        gridLayout_5->addWidget(b38, 5, 2, 1, 1);

        b17 = new QPushButton(layoutWidget4);
        b17->setObjectName(QString::fromUtf8("b17"));

        gridLayout_5->addWidget(b17, 2, 2, 1, 1);

        b37 = new QPushButton(layoutWidget4);
        b37->setObjectName(QString::fromUtf8("b37"));

        gridLayout_5->addWidget(b37, 5, 1, 1, 1);

        b35 = new QPushButton(layoutWidget4);
        b35->setObjectName(QString::fromUtf8("b35"));

        gridLayout_5->addWidget(b35, 4, 6, 1, 1);

        b6 = new QPushButton(layoutWidget4);
        b6->setObjectName(QString::fromUtf8("b6"));

        gridLayout_5->addWidget(b6, 0, 5, 1, 1);

        b29 = new QPushButton(layoutWidget4);
        b29->setObjectName(QString::fromUtf8("b29"));

        gridLayout_5->addWidget(b29, 4, 0, 1, 1);

        b41 = new QPushButton(layoutWidget4);
        b41->setObjectName(QString::fromUtf8("b41"));

        gridLayout_5->addWidget(b41, 5, 5, 1, 1);

        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 290, 101, 151));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(640, 330, 101, 91));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 802, 24));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);
        QObject::connect(SliderR, SIGNAL(valueChanged(int)), lcdNumber, SLOT(display(int)));
        QObject::connect(SliderG, SIGNAL(valueChanged(int)), lcdNumber_2, SLOT(display(int)));
        QObject::connect(SliderB, SIGNAL(valueChanged(int)), lcdNumber_3, SLOT(display(int)));
        QObject::connect(SliderX, SIGNAL(valueChanged(int)), lcdNumber_4, SLOT(display(int)));
        QObject::connect(SliderY, SIGNAL(valueChanged(int)), lcdNumber_5, SLOT(display(int)));
        QObject::connect(SliderZ, SIGNAL(valueChanged(int)), lcdNumber_6, SLOT(display(int)));
        QObject::connect(SliderR2, SIGNAL(valueChanged(int)), lcdNumber_7, SLOT(display(int)));
        QObject::connect(SliderPZ, SIGNAL(valueChanged(int)), lcdNumber_8, SLOT(display(int)));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        ButtonQuit->setText(QApplication::translate("MainWindow", "Sair", nullptr));
        ButtonCor->setText(QApplication::translate("MainWindow", "Aplicar cor", nullptr));
        Bcubo->setText(QApplication::translate("MainWindow", "Cubo", nullptr));
        BNcubo->setText(QApplication::translate("MainWindow", "NCubo", nullptr));
        Besfera->setText(QApplication::translate("MainWindow", "Esfera", nullptr));
        BNesfera->setText(QApplication::translate("MainWindow", "NEsfera", nullptr));
        Belipsoide->setText(QApplication::translate("MainWindow", "Elipsoide", nullptr));
        BNelipsoide->setText(QApplication::translate("MainWindow", "NElipsoide", nullptr));
        Bvoxel->setText(QApplication::translate("MainWindow", "Voxel", nullptr));
        BNvoxel->setText(QApplication::translate("MainWindow", "NVoxel", nullptr));
        labelG->setText(QApplication::translate("MainWindow", "G", nullptr));
        labelR->setText(QApplication::translate("MainWindow", "R", nullptr));
        labelB->setText(QApplication::translate("MainWindow", "B", nullptr));
        labelG_2->setText(QApplication::translate("MainWindow", "Raio y", nullptr));
        labelB_2->setText(QApplication::translate("MainWindow", "Raio z", nullptr));
        labelB_3->setText(QApplication::translate("MainWindow", "Raio", nullptr));
        labelR_2->setText(QApplication::translate("MainWindow", "Raio x", nullptr));
        labelR_3->setText(QApplication::translate("MainWindow", "Plano z", nullptr));
        b1->setText(QString());
        b2->setText(QString());
        b11->setText(QString());
        b19->setText(QString());
        b30->setText(QString());
        b10->setText(QString());
        b14->setText(QString());
        b36->setText(QString());
        b24->setText(QString());
        b9->setText(QString());
        b5->setText(QString());
        b18->setText(QString());
        b20->setText(QString());
        b27->setText(QString());
        b39->setText(QString());
        b8->setText(QString());
        b28->setText(QString());
        b3->setText(QString());
        b26->setText(QString());
        b16->setText(QString());
        b22->setText(QString());
        b31->setText(QString());
        b40->setText(QString());
        b15->setText(QString());
        b7->setText(QString());
        b25->setText(QString());
        b32->setText(QString());
        b12->setText(QString());
        b34->setText(QString());
        b4->setText(QString());
        b33->setText(QString());
        b13->setText(QString());
        b21->setText(QString());
        b23->setText(QString());
        b42->setText(QString());
        b38->setText(QString());
        b17->setText(QString());
        b37->setText(QString());
        b35->setText(QString());
        b6->setText(QString());
        b29->setText(QString());
        b41->setText(QString());
        label->setText(QApplication::translate("MainWindow", "UM MONSTRO", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "VIVO E S\303\203O!!!!", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
